import random
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
import requests
from selenium.webdriver.support.ui import Select
import pandas as pd
import asyncio
import subprocess
import os

browser = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
browser.get("https://www.employbl.com/tech-stacks")
time.sleep(3)

def extract_companies(cloud_platform,x):
    all_companies = []
    browser.find_element(By.LINK_TEXT, value=cloud_platform).click()
    time.sleep(2)
    print(f"Extracting companies using {cloud_platform}...")

    for i in range(x):

       dropdown = browser.find_element(By.XPATH, "//select[@class='mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50']")
       select = Select(dropdown)
       select.select_by_value("500")


       companies = browser.find_elements(By.XPATH, "//a[@class='underline hover:text-tangelo']")
       random.shuffle(companies)

       for p in companies[:500]:
           page = p.text.replace(" ", "-")
           url = f"https://www.employbl.com/companies/{page}"

           r = requests.get(url)
           bs = BeautifulSoup(r.text, "html.parser")
           link = bs.find('a', class_="flex items-center justify-center text-base font-medium text-indigo-600 sm:justify-start")

           if link is not None:
               href_value = link.get('href').replace("/", "")

               if href_value.startswith(("https:", "www.")):
                   href_value = href_value.split(":")[1] if href_value.startswith("https:") else href_value[4:]

               if href_value[:4]=="www.":
                   href_value=href_value.replace("www.","")

               href_url = f"https://www.{href_value}"

               all_companies.append({
                   "Website Name(Domain)": href_value,
                   "Website Url": href_url,
                   "Company Name": p.text,
                   "Cloud": cloud_platform.lower()
               })
       next_button = browser.find_element(by=By.XPATH,value="//button[contains(@class, 'border-gray-300') and contains(@class, 'bg-white') and contains(@class, 'text-gray-500') and contains(., 'Next')]")
       next_button.click()
    df = pd.DataFrame(all_companies)
    df.to_excel(f"{cloud_platform.lower()}.xlsx", index=False)
    print(f"Extraction for {cloud_platform} completed successfully")
    # for i in range(x):
    browser.back()
    time.sleep(3)

async def main():

    extract_companies("amazon web services",3)

    extract_companies("google cloud platform",1)

    extract_companies("microsoft azure",1)



def open_excel_file(file_name):

    file_path = os.path.join(os.getcwd(), file_name)
    if os.path.exists(file_path):
        try:
            subprocess.Popen(['start', 'excel', file_path], shell=True)
        except Exception as e:
            print(f"Error opening the Excel file: {e}")
    else:
        print(f"The file '{file_name}' does not exist.")





if __name__=="__main__":
    asyncio.run(main())
    print("Overall extraction completed")
    print("Opening the excel files")
    open_excel_file("amazon web services.xlsx")
    open_excel_file("google cloud platform.xlsx")
    open_excel_file("microsoft azure.xlsx")




